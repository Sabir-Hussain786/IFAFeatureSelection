ndnSIM
======

The ndnSIM is NS-3 module that implements Named Data Networking (NDN) communication model, the
clean slate Internet design. ndnSIM is specially optimized for simulation purposes and has a
clean and extensible internal structure.

[ndnSIM documentation](http://ndnsim.net)
-----------------------------------------

For more information, including downloading and compilation instruction, please refer to
http://ndnsim.net or documentation in `docs/` folder.
