#include "ndn-consumer.h"
#include "lcpf-uniform-attacker-single-prefix.h"
#include "ns3/ptr.h"
#include "ns3/log.h"
#include "ns3/simulator.h"
#include "ns3/packet.h"
#include "ns3/callback.h"
#include "ns3/string.h"
#include "ns3/boolean.h"
#include "ns3/uinteger.h"
#include "ns3/integer.h"
#include "ns3/double.h"

#include "ns3/ndn-l3-protocol.h"
#include "ns3/ndn-app-face.h"
#include "ns3/ndn-interest.h"
#include "ns3/ndn-data.h"
#include "ns3/ndn-pit.h"

#include <boost/algorithm/string.hpp>
#include <fstream>
#include "ns3/ndnSIM/utils/ndn-fw-hop-count-tag.h"

NS_LOG_COMPONENT_DEFINE ("LcpfUniformAttackerSinglePrefix");

namespace ns3 {
namespace ndn {

NS_OBJECT_ENSURE_REGISTERED (LcpfUniformAttackerSinglePrefix);

TypeId LcpfUniformAttackerSinglePrefix::GetTypeId (void)
{
    static TypeId tid = TypeId ("ns3::ndn::LcpfUniformAttackerSinglePrefix")
        .SetGroupName ("Ndn")
        .SetParent<App> ()
        .AddConstructor<LcpfUniformAttackerSinglePrefix> ()

        .AddAttribute ("Frequency", "Frequency of interest packets",
                StringValue ("1.0"),
                MakeDoubleAccessor (&LcpfUniformAttackerSinglePrefix::m_frequency),
                MakeDoubleChecker<double> ())

        .AddAttribute ("LifeTime", "LifeTime for interest packet",
                StringValue ("3s"),
                MakeTimeAccessor (&LcpfUniformAttackerSinglePrefix::m_interestLifeTime),
                MakeTimeChecker ())

        .AddAttribute ("Prefix", "Comma-seperated string of prefixes this client can request",
                StringValue ("/google.com"),
                MakeStringAccessor (&LcpfUniformAttackerSinglePrefix::m_p),
                MakeStringChecker ())

        .AddAttribute("NumberOfContents", "Number of the Contents in total", StringValue("3000"),
                MakeUintegerAccessor(&LcpfUniformAttackerSinglePrefix::SetNumberOfContents,
                                     &LcpfUniformAttackerSinglePrefix::GetNumberOfContents),
                MakeUintegerChecker<uint32_t>())

        .AddAttribute ("RelativeSetSize",
                "UniformAttacker relative requestsed set size",
                DoubleValue (0),
                MakeDoubleAccessor (&LcpfUniformAttackerSinglePrefix::m_relativeSetSize),
                MakeDoubleChecker<double> ())

        .AddAttribute ("StartAt",
                "When to start the attack. LcpfUniformAttackerSinglePrefixs do nothing before.",
                TimeValue (Minutes (10)),
                MakeTimeAccessor (&LcpfUniformAttackerSinglePrefix::m_startAt),
                MakeTimeChecker ())

        .AddAttribute ("StopAt",
                "When to stop the attack. LcpfUniformAttackerSinglePrefixs do nothing after.",
                TimeValue (Minutes (20)),
                MakeTimeAccessor (&LcpfUniformAttackerSinglePrefix::m_stopAt),
                MakeTimeChecker ())
        ;
    return tid;
}

LcpfUniformAttackerSinglePrefix::LcpfUniformAttackerSinglePrefix()
{}

void LcpfUniformAttackerSinglePrefix::StartApplication()
{


    NS_LOG_FUNCTION_NOARGS();

    
    // do base stuff
    App::StartApplication();

    m_randNonce = UniformVariable (0, std::numeric_limits<uint32_t>::max ());
    m_randomSeqId = UniformVariable (m_numberOfContents - ( m_numberOfContents * m_relativeSetSize ) , m_numberOfContents);
    m_randomTime = UniformVariable (0.0, 2 * 1.0 / m_frequency);

    Simulator::Schedule (m_startAt, &LcpfUniformAttackerSinglePrefix::ScheduleNextPacket, this);
    NS_LOG_INFO ("Requesting Interest: ");
}

void LcpfUniformAttackerSinglePrefix::StopApplication () // Called at time specified by Stop
{
  NS_LOG_FUNCTION_NOARGS ();

  // cancel periodic packet generation
  Simulator::Cancel (m_sendEvent);

  // cleanup base stuff
  App::StopApplication ();
}

void LcpfUniformAttackerSinglePrefix::ScheduleNextPacket()
{
    NS_LOG_INFO ("LcpfUniformAttackerSinglePrefix::ScheduleNextPacket()");
    if(!m_sendEvent.IsRunning())
        m_sendEvent = Simulator::Schedule (Seconds(m_randomTime.GetValue()), &LcpfUniformAttackerSinglePrefix::SendPacket, this);

}

void LcpfUniformAttackerSinglePrefix::SendPacket ()
{
  NS_LOG_INFO ("LcpfUniformAttackerSinglePrefix::SendPacket ()");

    NS_LOG_FUNCTION (this);

    uint32_t seq = GetNextSeq();

    Ptr<Name> nameWithSequence = Create<Name> (m_p);

    nameWithSequence->appendSeqNum (seq);

    Ptr<Interest> interest = Create<Interest> ();
    interest->SetNonce               (m_randNonce.GetValue ());
    interest->SetName                (nameWithSequence);
    interest->SetInterestLifetime    (m_interestLifeTime);

    NS_LOG_INFO ("Requesting Interest: " << *interest<<"::SEQ::"<<seq<<"::");

    m_transmittedInterests (interest, this, m_face);
    m_face->ReceiveInterest (interest);

    if(Simulator::Now() >= m_stopAt)
    {
        m_active = false;
    }
    else
    {
        ScheduleNextPacket();
    }
}

uint32_t LcpfUniformAttackerSinglePrefix::GetNextSeq()
{
    NS_LOG_INFO ("LcpfUniformAttackerSinglePrefix::GetNextSeq()");
    return m_randomSeqId.GetValue();

}

void
LcpfUniformAttackerSinglePrefix::SetNumberOfContents(uint32_t numOfContents)
{
  m_numberOfContents = numOfContents;
}

uint32_t
LcpfUniformAttackerSinglePrefix::GetNumberOfContents() const
{
  return m_numberOfContents;
}




} // namespace ndn
} // namespace ns3
