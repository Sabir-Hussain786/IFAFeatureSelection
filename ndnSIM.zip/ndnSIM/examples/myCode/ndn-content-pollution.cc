#include "ns3/random-variable-stream.h"
#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/ndnSIM-module.h"
#include <ns3/ndn-face.h>
using namespace ns3;
int
main (int argc, char *argv[])
{
  std::string traceFileName="traceCS", numOfContents="100";
  bool isAttack = true;
  double traceInterval=4, relativeSetSize=0.2;
  CommandLine cmd;
  cmd.AddValue ("attack", "attack", isAttack);
  cmd.AddValue ("traceFileName", "traceFileName", traceFileName);
  cmd.AddValue ("numOfContents", "numOfContents", numOfContents);
  cmd.AddValue ("traceInterval", "traceInterval", traceInterval);
  cmd.AddValue ("relativeSetSize", "relativeSetSize", relativeSetSize);
  cmd.Parse (argc, argv);

  AnnotatedTopologyReader topologyReader ("", 25);
  topologyReader.SetFileName("src/ndnSIM/examples/topologies/XC.txt");
  topologyReader.Read ();
 
  // Install NDN stack on all nodes
  ndn::StackHelper ndnHelper;
  ndnHelper.SetForwardingStrategy ("ns3::ndn::fw::BestRoute");
  ndnHelper.SetContentStore ("ns3::ndn::cs::Lru");
  ndnHelper.SetPit ("ns3::ndn::pit::Persistent");
  ndnHelper.InstallAll ();

  // Installing global routing interface on all nodes
  ndn::GlobalRoutingHelper ndnGlobalRoutingHelper;
  ndnGlobalRoutingHelper.InstallAll ();

  // configure routers

  //configure CS size
  Ptr<UniformRandomVariable> CSsize = CreateObject<UniformRandomVariable> ();
  CSsize->SetAttribute ("Min", DoubleValue (100));
  CSsize->SetAttribute ("Max", DoubleValue (101));

  Config::Set ("/NodeList/0/$ns3::ndn::ContentStore/MaxSize", UintegerValue (CSsize->GetValue()));//number after nodeList is global ID of the node(=node->GetId ())
  Config::Set ("/NodeList/1/$ns3::ndn::ContentStore/MaxSize", UintegerValue (CSsize->GetValue()));
  Config::Set ("/NodeList/2/$ns3::ndn::ContentStore/MaxSize", UintegerValue (CSsize->GetValue()));
  Config::Set ("/NodeList/3/$ns3::ndn::ContentStore/MaxSize", UintegerValue (CSsize->GetValue()));
  Config::Set ("/NodeList/4/$ns3::ndn::ContentStore/MaxSize", UintegerValue (CSsize->GetValue()));
  Config::Set ("/NodeList/5/$ns3::ndn::ContentStore/MaxSize", UintegerValue (CSsize->GetValue()));
  Config::Set ("/NodeList/6/$ns3::ndn::ContentStore/MaxSize", UintegerValue (CSsize->GetValue()));
  Config::Set ("/NodeList/7/$ns3::ndn::ContentStore/MaxSize", UintegerValue (CSsize->GetValue()));
  Config::Set ("/NodeList/8/$ns3::ndn::ContentStore/MaxSize", UintegerValue (CSsize->GetValue()));
  Config::Set ("/NodeList/9/$ns3::ndn::ContentStore/MaxSize", UintegerValue (CSsize->GetValue()));
  
  //configure PIT size
  Ptr<UniformRandomVariable> PITsize = CreateObject<UniformRandomVariable> ();
  PITsize->SetAttribute ("Min", DoubleValue (50));
  PITsize->SetAttribute ("Max", DoubleValue (800));

  Config::Set ("/NodeList/0/$ns3::ndn::Pit/MaxSize", UintegerValue (PITsize->GetValue()));//number after nodeList is global ID of the node(=node->GetId ())
  Config::Set ("/NodeList/1/$ns3::ndn::Pit/MaxSize", UintegerValue (PITsize->GetValue()));
  Config::Set ("/NodeList/2/$ns3::ndn::Pit/MaxSize", UintegerValue (PITsize->GetValue()));
  Config::Set ("/NodeList/3/$ns3::ndn::Pit/MaxSize", UintegerValue (PITsize->GetValue()));
  Config::Set ("/NodeList/4/$ns3::ndn::Pit/MaxSize", UintegerValue (PITsize->GetValue()));
  Config::Set ("/NodeList/5/$ns3::ndn::Pit/MaxSize", UintegerValue (PITsize->GetValue()));
  Config::Set ("/NodeList/6/$ns3::ndn::Pit/MaxSize", UintegerValue (PITsize->GetValue()));
  Config::Set ("/NodeList/7/$ns3::ndn::Pit/MaxSize", UintegerValue (PITsize->GetValue()));
  Config::Set ("/NodeList/8/$ns3::ndn::Pit/MaxSize", UintegerValue (PITsize->GetValue()));
  Config::Set ("/NodeList/9/$ns3::ndn::Pit/MaxSize", UintegerValue (PITsize->GetValue()));



  // Getting containers for the consumer/producer/attacker
  Ptr<Node> routers[9] = {Names::Find<Node>("R0"),Names::Find<Node>("R1"), Names::Find<Node>("R2"),
                          Names::Find<Node>("R3"), Names::Find<Node>("R4"),
                          Names::Find<Node>("R5"), Names::Find<Node>("R6"),
                          Names::Find<Node>("R7"), Names::Find<Node>("R8")};

  Ptr<Node> consumers[6] = {Names::Find<Node>("C0"),Names::Find<Node>("C1"), Names::Find<Node>("C2"),
                            Names::Find<Node>("C3"), Names::Find<Node>("C4"),
                            Names::Find<Node>("C5")};


  Ptr<Node> producers[3] = {Names::Find<Node>("P0"), Names::Find<Node>("P1"), 
				Names::Find<Node>("P2")};

  Ptr<Node> attackers[1] = {Names::Find<Node>("A0")};


      if(consumers[0] == 0 || consumers[1] == 0 
      || consumers[2] == 0 || consumers[3] == 0
      || consumers[4] == 0 || consumers[5] == 0 
      || producers[0] == 0 || producers[1] == 0 
      || producers[2] == 0 || attackers[0] == 0 
      || routers[0]   == 0 || routers[1]   == 0 
      || routers[2]   == 0 || routers[3]   == 0
      || routers[4]   == 0 || routers[5]   == 0
      || routers[6]   == 0 || routers[7]   == 0
      || routers[8]   == 0) {
    NS_FATAL_ERROR("Error in topology: one or more nodes among c1, c2, c3, c4,c5, c6, c7, c8, p1, p2, p3, p4, p5, p6, a1, a2, a3, a4 is missing");
  }

      // configure consumer
  Ptr<UniformRandomVariable> frequency = CreateObject<UniformRandomVariable> ();
  frequency->SetAttribute ("Min", DoubleValue (50));
  frequency->SetAttribute ("Max", DoubleValue (800));


   // install application to client 
  ndn::AppHelper consumerHelper("ns3::ndn::ConsumerZipfMandelbrot");
  consumerHelper.SetAttribute("LifeTime", StringValue("4s"));                    //  not sure   
  consumerHelper.SetAttribute("Randomize", StringValue("uniform"));
  consumerHelper.SetAttribute("NumberOfContents", StringValue(numOfContents));




  ApplicationContainer consumer1[6];
  ApplicationContainer consumer2[6];
  ApplicationContainer consumer3[6];
  for (int i=0; i< 6 ; i++)
  {
    consumerHelper.SetAttribute("Frequency", DoubleValue (frequency->GetValue()));
    consumerHelper.SetPrefix("/P0/data");
    consumer1[i] = consumerHelper.Install(consumers[i]);       
    consumer1[i].Start(Seconds(0));     
    consumer1[i].Stop(Seconds(200));

    consumerHelper.SetAttribute("Frequency", DoubleValue (frequency->GetValue()));
    consumerHelper.SetPrefix("/P1/data");
    consumer2[i] = consumerHelper.Install(consumers[i]);       
    consumer2[i].Start(Seconds(0));     
    consumer2[i].Stop(Seconds(200));

    consumerHelper.SetAttribute("Frequency", DoubleValue (frequency->GetValue()));
    consumerHelper.SetPrefix("/P2/data");
    consumer3[i] = consumerHelper.Install(consumers[i]);       
    consumer3[i].Start(Seconds(0));     
    consumer3[i].Stop(Seconds(200));
  }

  //configure attacker 


  if(isAttack==true){
  ndn::AppHelper attackerHelper("ns3::ndn::LcpfUniformAttacker");
  attackerHelper.SetAttribute("Frequency", StringValue("1500"));                    //  not sure   
  attackerHelper.SetAttribute("Prefixes", StringValue("/P0/data,/P1/data,/P2/data"));
  attackerHelper.SetAttribute("NumberOfContents", StringValue(numOfContents));                    //  not sure   
  attackerHelper.SetAttribute("RelativeSetSize", DoubleValue(relativeSetSize));  
  attackerHelper.SetAttribute("StartAt", StringValue("50"));
  attackerHelper.SetAttribute("StopAt", StringValue("150"));
  attackerHelper.Install (attackers[0]);
  }
                     ///////////////////////////////////////////////
                     // install producer app on producer node p_i //
                     ///////////////////////////////////////////////


    for (uint32_t i = 0; i < 3; i++) {                                                  //  except P5 which will act as hijacke
    ndn::AppHelper producerHelper("ns3::ndn::Producer");
    std::string prefix = "/"+Names::FindName(producers[i]);
    ndnGlobalRoutingHelper.AddOrigins(prefix, producers[i]);
    prefix+="/data";
    producerHelper.SetPrefix(prefix);
    producerHelper.SetAttribute("PayloadSize", StringValue("1024"));   // not mentioned in paper
    ApplicationContainer producer = producerHelper.Install(producers[i]);
    }




    // Calculate and install FIBs
    ndn::GlobalRoutingHelper::CalculateRoutes();
    Simulator::Stop(Seconds(200));
    ndn::CsTracer::InstallAll (traceFileName, Seconds (traceInterval));

    Simulator::Run();
    Simulator::Destroy();

  return 0;
}

