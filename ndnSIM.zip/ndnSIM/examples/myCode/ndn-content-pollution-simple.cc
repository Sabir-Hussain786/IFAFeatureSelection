#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/ndnSIM-module.h"

using namespace ns3;
int 
main (int argc, char *argv[])
{
  AnnotatedTopologyReader topologyReader ("", 25);
  topologyReader.SetFileName("src/ndnSIM/examples/topologies/linear.txt");
  topologyReader.Read ();
 // Getting containers for the consumer/producer/attacker
  Ptr<Node> routers[7] = {Names::Find<Node>("R0"),Names::Find<Node>("R1"), Names::Find<Node>("R2"),
                          Names::Find<Node>("R3"), Names::Find<Node>("R4"),
                          Names::Find<Node>("R5"), Names::Find<Node>("R6")};
  Ptr<Node> consumers[1] = {Names::Find<Node>("C0")};
  Ptr<Node> producers[1] = {Names::Find<Node>("P0")};
  Ptr<Node> attackers[1] = {Names::Find<Node>("A0")};
  // Install NDN stack on all nodes
  ndn::StackHelper ndnHelper;
  ndnHelper.SetForwardingStrategy ("ns3::ndn::fw::BestRoute");
  ndnHelper.SetContentStore ("ns3::ndn::cs::Lru","MaxSize", "200");
  ndnHelper.SetPit ("ns3::ndn::pit::Persistent","MaxSize", "12000kb");
  ndnHelper.InstallAll ();
  // Installing global routing interface on all nodes
  ndn::GlobalRoutingHelper ndnGlobalRoutingHelper;
  ndnGlobalRoutingHelper.InstallAll ();

   // install application to client 
  ApplicationContainer consumer;
  ndn::AppHelper consumerHelper("ns3::ndn::ConsumerZipfMandelbrot");
  consumerHelper.SetAttribute("LifeTime", StringValue("4s"));                      
  consumerHelper.SetAttribute("Randomize", StringValue("uniform"));
  consumerHelper.SetAttribute("NumberOfContents", StringValue("3000"));
  consumerHelper.SetAttribute("Frequency", DoubleValue (900));
    consumerHelper.SetPrefix("/producer1");
    consumer = consumerHelper.Install(consumers[0]);       
    consumer.Start(Seconds(0));     
    consumer.Stop(Seconds(2000));


  //configure attacker
  ndn::AppHelper attackerHelper("ns3::ndn::LcpfUniformAttackerSinglePrefix");
  attackerHelper.SetAttribute("Frequency", StringValue("500"));                    
  attackerHelper.SetAttribute("Prefix", StringValue("/producer2"));
  attackerHelper.SetAttribute("NumberOfContents", StringValue("3000"));                   
  attackerHelper.SetAttribute("RelativeSetSize", DoubleValue(0.9));  
  attackerHelper.SetAttribute("StartAt", StringValue("700"));
  attackerHelper.SetAttribute("StopAt", StringValue("1500"));
  attackerHelper.Install (attackers[0]);



                                                 
    ndn::AppHelper producerHelper("ns3::ndn::Producer");
    ndnGlobalRoutingHelper.AddOrigins("/producer1", producers[0]);
    producerHelper.SetPrefix("/producer1");
    producerHelper.SetAttribute("PayloadSize", StringValue("1024"));   
    ApplicationContainer producer1 = producerHelper.Install(producers[0]);
    ndnGlobalRoutingHelper.AddOrigins("/producer2", producers[0]);
    producerHelper.SetPrefix("/producer2");
    ApplicationContainer producer2 = producerHelper.Install(producers[0]);
  // Calculate and install FIBs
    ndn::GlobalRoutingHelper::CalculateRoutes();
    Simulator::Stop(Seconds(2001));
    ndn::CsTracer::InstallAll ("traceCS.txt", Seconds (10));

    Simulator::Run();
    Simulator::Destroy();


  return 0;
}
