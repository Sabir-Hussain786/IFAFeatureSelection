#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/ndnSIM-module.h"
#include <ns3/ndn-face.h>
using namespace ns3;



void
PeriodicStatsPrinter (Ptr<Node> node, Time next)
{
  Ptr<ndn::Pit> pit = node->GetObject<ndn::Pit> ();
   int count[10]={0};
   for (Ptr<ndn::pit::Entry> entry = pit->Begin (); entry != pit->End (); entry = pit->Next (entry))
    {
       std::set< ndn::pit::IncomingFace > in = entry->GetIncoming ();
        for (std::set<ndn::pit::IncomingFace>::iterator it=in.begin(); it!=in.end(); ++it)
          {
             count[it->m_face->GetId()]++;             
          }
    }

  for (uint32_t i=0; i< node->GetNDevices(); i++){
  std::cout << Simulator::Now ().ToDouble (Time::S) << "\t"
            << node->GetId () << "\t"
            << Names::FindName (node) << "\t"
            << i << "\t"
            << count[i] << "\t"
            << pit->GetSize () << "\n";
}


  Simulator::Schedule (next, PeriodicStatsPrinter, node, next);
}



int
main (int argc, char *argv[])
{
  int mul=4;
  std::string traceFileName;
  CommandLine cmd;
  cmd.AddValue ("attackMultiplier", "attackMultiplier", mul);
  cmd.AddValue ("traceFileName", "traceFileName", traceFileName);


  cmd.Parse (argc, argv);

  AnnotatedTopologyReader topologyReader ("", 25);
   topologyReader.SetFileName("src/ndnSIM/examples/topologies/posidon.txt");
  topologyReader.Read ();
 
  // Install NDN stack on all nodes
  ndn::StackHelper ndnHelper;
  ndnHelper.SetForwardingStrategy ("ns3::ndn::fw::BestRoute");
  ndnHelper.SetContentStore ("ns3::ndn::cs::Lru","MaxSize", "1000");//added by me
  ndnHelper.SetPit ("ns3::ndn::pit::Persistent","MaxSize", "12000kb");//added by me

 
  ndnHelper.InstallAll ();
  // Installing global routing interface on all nodes
  ndn::GlobalRoutingHelper ndnGlobalRoutingHelper;
  ndnGlobalRoutingHelper.InstallAll ();


               // Getting containers for the consumer/producer/attacker
  Ptr<Node> routers[7] = {Names::Find<Node>("R1"), Names::Find<Node>("R2"),
                          Names::Find<Node>("R3"), Names::Find<Node>("R4"),
                          Names::Find<Node>("R5"), Names::Find<Node>("R6"),
                          Names::Find<Node>("R7")};

  Ptr<Node> consumers[16] = {Names::Find<Node>("C1"), Names::Find<Node>("C2"),
                            Names::Find<Node>("C3"), Names::Find<Node>("C4"),
                            Names::Find<Node>("C5"), Names::Find<Node>("C6"),
                            Names::Find<Node>("C7"), Names::Find<Node>("C8"),
                            Names::Find<Node>("C9"), Names::Find<Node>("C10"),
                            Names::Find<Node>("C11"), Names::Find<Node>("C12"),
                            Names::Find<Node>("C13"), Names::Find<Node>("C14"),
                            Names::Find<Node>("C15"), Names::Find<Node>("C16")};
  Ptr<Node> producers[2] = {Names::Find<Node>("P1"), Names::Find<Node>("P2")};
  Ptr<Node> attackers[3] = {Names::Find<Node>("A1"), Names::Find<Node>("A2"),
                            Names::Find<Node>("A3")};


   if (consumers[0] == 0 || consumers[1] == 0 || consumers[2] == 0 || consumers[3] == 0
      || consumers[4] == 0 || consumers[5] == 0 || consumers[6] == 0 || consumers[7] == 0
      || consumers[8] == 0 || consumers[9] == 0 || consumers[10] == 0 || consumers[11] == 0
      || consumers[12] == 0 || consumers[13] == 0 || consumers[14] == 0 || consumers[15] == 0
      || producers[0] == 0 || producers[1] == 0
      || attackers[0] == 0 || attackers[1] == 0 
      || attackers[2] == 0) {
    NS_FATAL_ERROR("Error in topology: one or more nodes among c1, c2, c3, c4,c5, c6, c7, c8, p1, p2, p3, p4, p5, p6, a1, a2, a3, a4 is missing");
  }


        // configure consumer
        ndn::AppHelper consumerHelper("ns3::ndn::ConsumerCbr");
        consumerHelper.SetAttribute("LifeTime", StringValue("4s"));                    //  not sure   
        consumerHelper.SetAttribute("Frequency", DoubleValue (100));
        consumerHelper.SetAttribute("Randomize", StringValue("uniform"));
        ApplicationContainer consumer1[16];
        ApplicationContainer consumer2[16];
        for (int i=0; i< 16 ; i++)
        {
        consumerHelper.SetPrefix("/P1/data");
        consumer1[i] = consumerHelper.Install(consumers[i]);       
        consumer1[i].Start(Seconds(0));     
        consumer1[i].Stop(Seconds(300));
        consumerHelper.SetPrefix("/P2/data");
        consumer2[i] = consumerHelper.Install(consumers[i]);       
        consumer2[i].Start(Seconds(0));     
        consumer2[i].Stop(Seconds(300));
        }

        // configure attacker
        consumerHelper.SetAttribute("Frequency", DoubleValue (100*mul));
        ApplicationContainer attacker1[3];
        ApplicationContainer attacker2[3];
        for (int i=0; i< 3 ; i++)
        {
        consumerHelper.SetPrefix("/P1/data");
        attacker1[i] = consumerHelper.Install(attackers[i]);       
        attacker1[i].Start(Seconds(60));     
        attacker1[i].Stop(Seconds(120));
        attacker1[i].Start(Seconds(180));     
        attacker1[i].Stop(Seconds(240));
        consumerHelper.SetPrefix("/P2/data");
        attacker2[i] = consumerHelper.Install(attackers[i]);       
        attacker2[i].Start(Seconds(60));     
        attacker2[i].Stop(Seconds(120));
        attacker2[i].Start(Seconds(180));     
        attacker2[i].Stop(Seconds(240));
        }
        // configure publisher 
        for (int i = 0; i < 2; i++) 
        {                                               
        ndn::AppHelper producerHelper("ns3::ndn::Producer");
        std::string prefix = "/"+Names::FindName(producers[i]);
        ndnGlobalRoutingHelper.AddOrigins(prefix, producers[i]);
        prefix+="/data";
        producerHelper.SetPrefix(prefix);
        producerHelper.SetAttribute("PayloadSize", StringValue("1024"));  
        ApplicationContainer producer = producerHelper.Install(producers[i]);
        }


  ndn::GlobalRoutingHelper::CalculateRoutes();
  Simulator::Stop(Seconds(301));
  Simulator::Run();
  Simulator::Destroy();

  return 0;
}


